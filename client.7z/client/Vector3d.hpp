#pragma once
#ifndef VECTOR3D_H_I0UEF3KR
#define VECTOR3D_H_I0UEF3KR
#include "rpc/msgpack.hpp"
#include <vector>

struct Vector3d {
	unsigned char x, y, z;
	
};


#endif